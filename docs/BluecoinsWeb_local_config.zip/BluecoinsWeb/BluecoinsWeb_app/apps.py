from django.apps import AppConfig


class BluecoinsAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "BluecoinsWeb_app"
